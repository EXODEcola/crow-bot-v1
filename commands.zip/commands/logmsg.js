const { MessageEmbed } = require('discord.js')
const db = require('quick.db')

module.exports = {
    name: 'logmessage',
    aliases: ["logmsg"],
    run: async (client, message, args) => {
let prefix =  db.get(` ${process.env.owner}.prefix`)
if(prefix === null) prefix = process.env.prefix;
  let color = db.get(`${process.env.owner}.color`) 
   if(color === null  ) color = process.env.color
        if(process.env.owner ===message.author.id || db.get(`ownermd.${message.author.id}`) === true || db.get(`${message.guild.id}.${message.author.id}.wlmd`) === true) {
 
            let ss = message.mentions.channels.first() || message.guild.channels.cache.get(args[0])
        if(args[0] === "on") {
            const channel = message.channel

            db.set(`${message.guild.id}.msglog`, channel.id)
            message.channel.send(`Le salon ${channel} sera maintenant utilisé pour envoyer les logs de message`)
        }

        else if(args[0] === "off") {
            db.set(`${message.guild.id}.msglog`,null)
            message.channel.send(`Logs de message désactivés`)
            
        } else 
             if(ss) {
            db.set(`${message.guild.id}.msglog`, ss.id)
            message.channel.send(`Le salon ${ss} sera maintenant utilisé pour envoyer les logs de message`)
        }

        } else {

        }
    }
}